#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sql.h>
#include <sqlext.h>
#include "odbc.h"
#include "products.h"
#include "connection.h"


#define Buferlen 512
#define Buferlen2 30

SQLHENV env=NULL;
SQLHDBC dbc=NULL;
SQLHSTMT stmt=NULL;

int StockMenu(){
    /**/
    int ret;
    char query[Buferlen]="\0";
    char x[Buferlen]="\0";
    char quantityinstock[Buferlen]="\0";
    /*SQLRETURN ret2;*/
    (void) snprintf(query, (size_t)(Buferlen+624), "SELECT quantityinstock FROM products WHERE productcode = ?");


    ret=prepareconnect_handle(query);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
        
    
   
    printf("productcode = ");
    (void) fflush(stdout);
    scanf("%s", x);
    
    (void) SQLBindParameter(stmt,1,SQL_PARAM_INPUT, SQL_C_CHAR,
                                    SQL_CHAR,0,0,x,0,NULL);
    (void) SQLExecute(stmt);
    (void) SQLBindCol(stmt, 1, SQL_C_CHAR,(SQLCHAR *)quantityinstock,Buferlen/*longitud de dato y*/, NULL);
    
    while (SQL_SUCCEEDED(ret=SQLFetch (stmt))){
        printf("Unidades en stock: %s\n", quantityinstock);
    }

    (void) SQLCloseCursor(stmt);

        /*volver a pedir*/

    ret=disconnect_handle(env, dbc, stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    return EXIT_SUCCESS;

}
int FindMenu(){
    
    char x[Buferlen]="\0";
    char productcode[Buferlen]="\0";
    /*SQLRETURN ret2;*/
    int ret;

    ret = odbc_connect(&env, &dbc);
    if (!SQL_SUCCEEDED(ret)) {
        return EXIT_FAILURE;
    }
    /**/
    /* Allocate a statement handle */
    
    ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
    ret= SQLPrepare(stmt, (SQLCHAR*) "SELECT productcode FROM products WHERE productname = ? ORDER BY productcode", SQL_NTS);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
        
    
    printf("productname = ");
    (void) fflush(stdout);
    if(fgets(x, Buferlen, stdin)){
        x[strcspn(x, "\n")]= '\0';
    }
    
    printf("\n");
    (void) SQLBindParameter(stmt,1,SQL_PARAM_INPUT, SQL_C_CHAR,
                                    SQL_CHAR,0,0,x,0,NULL);
    (void) SQLExecute(stmt);
    (void) SQLBindCol(stmt, 1, SQL_C_CHAR,(SQLCHAR *)productcode,Buferlen/*longitud de dato y*/, NULL);
    
    while (SQL_SUCCEEDED(ret=SQLFetch (stmt))){
        printf("%s || %s\n", productcode, x);
    }

    (void) SQLCloseCursor(stmt);

        /*volver a pedir*/
    (void) fflush(stdout);
    
    printf("\n");

    ret=disconnect_handle(env, dbc, stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    return EXIT_SUCCESS;

}
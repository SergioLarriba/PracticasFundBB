#ifndef CON_H
#define CON_H


int pconnect_handle(SQLHENV env, SQLHDBC dbc, SQLHSTMT stmt, char *query);



int disconnect_handle(SQLHENV env, SQLHDBC dbc, SQLHSTMT stmt);













#endif
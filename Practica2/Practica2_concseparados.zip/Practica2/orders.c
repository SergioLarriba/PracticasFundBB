#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sql.h>
#include <sqlext.h>
#include "odbc.h"
#include "orders.h"
#include "connection.h"

#define Buferlen 512
#define Buferlen2 30

    
int oOpenMenu(SQLHSTMT stmt){

    int ret;
    char ordernumber[Buferlen]="\0";
    
    
    ret= SQLPrepare(stmt, (SQLCHAR*) "SELECT orders.ordernumber FROM orders WHERE orders.shippeddate IS NULL order by(orders.ordernumber)", SQL_NTS);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }

    (void) SQLExecute(stmt);
    (void) SQLBindCol(stmt, 1, SQL_C_CHAR,(SQLCHAR *)ordernumber,Buferlen/*longitud de dato y*/, NULL);
    
    while (SQL_SUCCEEDED(ret=SQLFetch (stmt))){
        printf("%s\n", ordernumber);
        printf("\n");
    }

    (void) SQLCloseCursor(stmt);

    return EXIT_SUCCESS;
}

int rRangeMenu(SQLHSTMT stmt){

    int ret;
    
    char fecha[Buferlen] = "\0"; 
    char fecha_minima[Buferlen] = "\0";
    char fecha_maxima[Buferlen] = "\0";
    char ordernumber[Buferlen] = "\0"; 
    char orderdate[Buferlen] = "\0"; 
    char shippeddate[Buferlen] = "\0";
    int i, j; 
    

    ret= SQLPrepare(stmt, (SQLCHAR*) "SELECT ordernumber, orderdate, shippeddate FROM orders WHERE orderdate>= ? and orderdate<= ? order by(ordernumber);", SQL_NTS);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }


    printf("Enter dates (YYYY-MM-DD - YYYY-MM-DD) > ");
    (void) fflush(stdout);
    if(fgets(fecha, Buferlen, stdin)){
        fecha[strcspn(fecha, "\n")]= '\0';
    } 
       
    /* Separo las 2 fechas en 2 variables */
    for (i=0; i<=9; i++) {
        fecha_minima[i]=fecha[i]; 
    }
    for (i=0, j=13; i<=9; i++, j++) {
        fecha_maxima[i]=fecha[j]; 
    }

    (void) SQLBindParameter(stmt,1,SQL_PARAM_INPUT, SQL_C_CHAR,
                                    SQL_CHAR,0,0,fecha_minima,0,NULL);
    (void) SQLBindParameter(stmt,2,SQL_PARAM_INPUT, SQL_C_CHAR,
                                    SQL_CHAR,0,0,fecha_maxima,0,NULL);

    (void) SQLExecute(stmt);

    (void) SQLBindCol(stmt, 1, SQL_C_CHAR, (SQLCHAR*) ordernumber, Buferlen , NULL);
    (void) SQLBindCol(stmt, 2, SQL_C_CHAR, (SQLCHAR*) orderdate, Buferlen , NULL);
    (void) SQLBindCol(stmt, 3, SQL_C_CHAR, (SQLCHAR*) shippeddate, Buferlen , NULL);

    /* Loop through the rows in the result-set */
    while (SQL_SUCCEEDED(ret = SQLFetch(stmt))) {
        printf("%s %s %s\n", ordernumber, orderdate, shippeddate);
        printf("\n");
    }

    (void) SQLCloseCursor(stmt);

    return EXIT_SUCCESS;
}

int dDetailMenu(SQLHSTMT stmt, SQLHSTMT stmt2){

    
    int ret, i=0;  
    
    char ordernumber[Buferlen] = "\0"; 
    char orderdate[Buferlen] = "\0";
    char status[Buferlen] = "\0";
    char total[Buferlen] = "\0"; 
    char productcode[Buferlen] = "\0"; 
    char quantityordered[Buferlen] = "\0";
    char priceeach[Buferlen] = "\0";
    
    ret = SQLPrepare(stmt, (SQLCHAR*) "SELECT orders.orderdate, orders.status, orderdetails.productcode,  orderdetails.quantityordered, orderdetails.priceeach, (orderdetails.priceeach * orderdetails.quantityordered) as suma, orderdetails.orderlinenumber FROM orders natural join orderdetails natural join products WHERE orders.ordernumber= ? group by orders.orderdate, orders.status, orderdetails.productcode, orderdetails.quantityordered, orderdetails.priceeach, orderdetails.orderlinenumber order by(orderdetails.orderlinenumber)", SQL_NTS);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    printf ("Enter ordernumber > "); 
    (void)fflush(stdout); 
    if(fgets(ordernumber, Buferlen, stdin)){
        ordernumber[strcspn(ordernumber, "\n")]= '\0';
    }

    (void) SQLBindParameter(stmt,1,SQL_PARAM_INPUT, SQL_C_CHAR,
                                    SQL_CHAR,0,0,ordernumber,0,NULL);

    (void) SQLExecute(stmt); 

    (void) SQLBindCol(stmt, 1, SQL_C_CHAR, (SQLCHAR*) orderdate, Buferlen, NULL);
    (void) SQLBindCol(stmt, 2, SQL_C_CHAR, (SQLCHAR*) status, Buferlen, NULL);
    (void) SQLBindCol(stmt, 3, SQL_C_CHAR, (SQLCHAR*) productcode, Buferlen , NULL);
    (void) SQLBindCol(stmt, 4, SQL_C_CHAR, (SQLCHAR*) quantityordered, Buferlen , NULL);
    (void) SQLBindCol(stmt, 5, SQL_C_CHAR, (SQLCHAR*) priceeach, Buferlen, NULL);
        
    (void) SQLBindParameter(stmt2,1,SQL_PARAM_INPUT, SQL_C_CHAR,
                                SQL_CHAR,0,0,ordernumber,0,NULL);
        
    (void) SQLExecute(stmt2); 

    (void) SQLBindCol(stmt2, 1, SQL_C_CHAR, (SQLCHAR*) total, Buferlen , NULL);

    (void) SQLFetch(stmt2); 

    while (SQL_SUCCEEDED(ret = SQLFetch(stmt))) {
        if (i == 0) {
            printf ("----------------------\n"); 
            printf ("%s %s\n", orderdate, status);
            printf ("--------------------\n");  
            printf ("Totalcost: %s \n", total); 
            printf ("--------------------\n");  
            i++; 
        }
        printf ("%s %s %s\n", productcode, quantityordered, priceeach); 
    }

    (void) SQLCloseCursor(stmt);

    return EXIT_SUCCESS;
}
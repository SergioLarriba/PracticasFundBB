
#ifndef ORD_H
#define ORD_H





int oOpenMenu(SQLHSTMT stmt);

int rRangeMenu(SQLHSTMT stmt);

int dDetailMenu(SQLHSTMT stmt, SQLHSTMT stmt2);




#endif
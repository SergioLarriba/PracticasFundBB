#ifndef PRO_H
#define PRO_H


/*Solicita un identificador de producto (productcode)
y se devuelve el número de unidades del producto en stock.*/

int sStockMenu(SQLHSTMT stmt);


/*Se solicita al usuario el nombre del producto y se devuelve un listado
con todos los productos cuyo nombre una cadena pedida.
Cada línea de la salida contendrá dos cadenas productcode y productname. La salida estar´a ordenada por el atributo productcode. N´otese que la salida puede
constar de m´as de un producto.*/

int fFindMenu(SQLHSTMT stmt);


#endif
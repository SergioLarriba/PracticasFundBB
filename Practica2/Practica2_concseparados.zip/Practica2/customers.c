#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sql.h>
#include <sqlext.h>
#include "odbc.h"
#include "customers.h"
#include "connection.h"

#define Buferlen 512
#define Buferlen2 30



int fFindMenu2(SQLHSTMT stmt){

    char x[Buferlen]="\0";
    char customername[Buferlen]="\0";
    char contactfirstname[Buferlen]="\0";
    char contactlastname[Buferlen]="\0";
    char customernumber[Buferlen]="\0";
    char cadena[Buferlen]="%%%"; 
    int ret;

    ret= SQLPrepare(stmt, (SQLCHAR*) "SELECT customernumber, customername, contactfirstname, contactlastname FROM customers WHERE contactfirstname like ? or contactlastname like ? ORDER BY customernumber", SQL_NTS);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
        
    printf("Enter customer name > ");
    (void) fflush(stdout);
    if(fgets(x, Buferlen, stdin)){
        x[strcspn(x, "\n")]= '\0';
    }

    strcat(cadena, x); 
    strcat(cadena, "%%"); 

    printf("\n");

    (void) SQLBindParameter(stmt,1,SQL_PARAM_INPUT, SQL_C_CHAR,
                                    SQL_CHAR,0,0,cadena,0,NULL);
    (void) SQLBindParameter(stmt,2,SQL_PARAM_INPUT, SQL_C_CHAR,
                                    SQL_CHAR,0,0,cadena,0,NULL);
    (void) SQLExecute(stmt);    
        
    (void) SQLBindCol(stmt, 1, SQL_C_CHAR,(SQLCHAR *)customername,Buferlen, NULL);
    (void) SQLBindCol(stmt, 2, SQL_C_CHAR,(SQLCHAR *)contactfirstname,Buferlen, NULL);
    (void) SQLBindCol(stmt, 3, SQL_C_CHAR,(SQLCHAR *)contactlastname,Buferlen, NULL);
    (void) SQLBindCol(stmt, 4, SQL_C_CHAR,(SQLCHAR *)customernumber,Buferlen, NULL);



    while (SQL_SUCCEEDED(ret=SQLFetch (stmt))){
        printf("%s %s %s %s", customername ,contactfirstname, contactlastname, customernumber);
        printf("\n");
    }
    
    (void) SQLCloseCursor(stmt);

    return EXIT_SUCCESS;
}




int bBalanceMenu(SQLHSTMT stmt){

    char customernumber[Buferlen]="\0";
    char total[Buferlen]="\0";
    int ret;

    
    ret = SQLPrepare(stmt, (SQLCHAR *)"select (select sum(pa.amount) from payments pa where pa.customernumber = ?) - (select sum(od.quantityordered*od.priceeach) from orders o, orderdetails od where o.customernumber = ? and o.ordernumber = od.ordernumber);", SQL_NTS);
    if (!SQL_SUCCEEDED(ret))
    {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    
    printf("Enter customer number > ");
    (void) fflush(stdout);
    if(fgets(customernumber, Buferlen, stdin)){
        customernumber[strcspn(customernumber, "\n")]= '\0';
    }
    
    (void) SQLBindParameter(stmt,1,SQL_PARAM_INPUT, SQL_C_CHAR,
                                    SQL_CHAR,0,0,customernumber,0,NULL);
    (void) SQLBindParameter(stmt,2,SQL_PARAM_INPUT, SQL_C_CHAR,
                                    SQL_CHAR,0,0,customernumber,0,NULL);

    (void) SQLExecute(stmt);    
            
    (void) SQLBindCol(stmt, 1, SQL_C_CHAR,(SQLCHAR *)total,Buferlen/*longitud de dato y*/, NULL);

    while (SQL_SUCCEEDED(ret=SQLFetch (stmt))){
        printf("Balance = %s\n",total);
        printf("\n");
    }

    (void) SQLCloseCursor(stmt);

    return EXIT_SUCCESS;
}



int lListProductsMenu (SQLHSTMT stmt){

    int ret;
    char customernumber[Buferlen]="\0";
    char ordernumber[Buferlen]="\0";
    char total[Buferlen]="\0";
    

    
    ret= SQLPrepare(stmt, (SQLCHAR*) "SELECT p.productname, sum(od.quantityordered) FROM products p join orderdetails od on od.productcode=p.productcode join orders o on od.ordernumber=o.ordernumber join customers c on c.customernumber=o.customernumber where c.customernumber=? group by p.productname, p.productcode order by p.productcode ", SQL_NTS);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }

    printf("Enter customer number > ");
    (void) fflush(stdout);
    if(fgets(customernumber, Buferlen, stdin)){
        customernumber[strcspn(customernumber, "\n")]= '\0';
    }
    (void) SQLBindParameter(stmt,1,SQL_PARAM_INPUT, SQL_C_CHAR,
                                    SQL_CHAR,0,0,customernumber,0,NULL);
    (void) SQLExecute(stmt);
        
    (void) SQLBindCol(stmt, 1, SQL_C_CHAR,(SQLCHAR *)ordernumber,Buferlen/*longitud de dato y*/, NULL);
    (void) SQLBindCol(stmt, 2, SQL_C_CHAR,(SQLCHAR *)total,Buferlen/*longitud de dato y*/, NULL);
            
    while (SQL_SUCCEEDED(ret=SQLFetch (stmt))){
        printf("%s %s\n", ordernumber,total);
    }

    (void) SQLCloseCursor(stmt);

    return EXIT_SUCCESS;
}
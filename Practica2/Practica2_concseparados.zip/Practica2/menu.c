#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sql.h>
#include <sqlext.h>
#include "odbc.h"
#include "products.h"
#include "orders.h"
#include "customers.h"
#include "connection.h"

#define Buferlen 512
#define Buferlen2 30

static int ShowMainMenu();
static int ShowCustomersMenu();
static void ShowOrdersMenu();
static int ShowProductMenu();
static int ShowProductSubMenu();
static int ShowCustomersSubMenu();
static int ShowOrdersSubMenu();
int StockMenu();
int FindMenu();
int FindMenu2();
int ListProductsMenu();
int BalanceMenu(); 

SQLHENV env=NULL;
SQLHDBC dbc=NULL;
SQLHSTMT stmt=NULL;


int main(void){
    int choice=0; 

    do{
        choice=ShowMainMenu();
        switch(choice){
            case 1: {
                ShowProductMenu(); 
            }
                break;
            case 2:{
                ShowOrdersMenu();
            }
                break;
            case 3:{
                ShowCustomersMenu(); 
            }
                break;
            case 4:{
                printf("Has salido");
                printf("\n");
            }
                break;
        }
    }while(choice!=4);

    return 0;
}

int ShowMainMenu() {
    int number = 0;
    char buf[16];

    do {
        printf("Este programa mostrará un menú de 4 opciones\n");
        printf("Segun el numero que insertes accederas al submenú correspondiente\n\n");

        printf(" (1) Products\n"
               " (2) Orders\n"
               " (3) Customers\n"
               " (4) Exit\n\n"
               "Enter a number that corresponds to your choice > ");
        if (!fgets(buf, 16, stdin))
            
            number =0;
        else
            
            number = atoi(buf);
        printf("\n");

        if ((number < 1) || (number > 4)) {
            printf("You have entered an invalid choice. Please try again\n\n");
        }
    } while ((number < 1) || (number > 4));

    return number;
}

/*******************************************************************************PRODUCTS***********************************************************************/

int ShowProductMenu() {
    int number= 0;
    int flag;
    
    do{
        flag=0; 
        number=ShowProductSubMenu();
        switch (number) {

            case 1: {
                StockMenu();
                flag=1; 
            }
                break; 

            case 2: {
                FindMenu();
                flag=1; 
            }
                break;

            case 3: {
                printf("\n");
            }
                break;

        }
    } while (number!= 3 && flag==1);
    return 0;
}

int ShowProductSubMenu() {
    int number = 0;
    char buf[16];

    do{
        printf(" (1) Stock\n"
               " (2) Find\n"
               " (3) Back\n\n"
               "Enter a number that corresponds to your choice > ");
        if (!fgets(buf, 16, stdin))
            
            number =0;
        else
            number = atoi(buf);
        printf("\n");

        if ((number < 1) || (number > 3)) {
            printf("You have entered an invalid choice. Please try again\n\n");
        }
    } while ((number < 1) || (number > 3));

    return number;
}

int StockMenu(){
    /**/
    int ret;
    
    ret=odbc_connect(&env,&dbc);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
    ret=sStockMenu(stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    
    ret=disconnect_handle(env, dbc, stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    return EXIT_SUCCESS;

}

int FindMenu(){
    /**/
    int ret;
    
    ret=odbc_connect(&env,&dbc);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
    ret=fFindMenu(stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    
    ret=disconnect_handle(env, dbc, stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }

    return EXIT_SUCCESS;
}

/*******************************************************************************ORDERS***********************************************************************/

void ShowOrdersMenu() {
    int number=0, flag;
    do {
        flag=0; 
        number=ShowOrdersSubMenu();
        switch (number) {

            case 1: {
                OpenMenu();
                flag=1; 
            }
                break;

            case 2: {
                RangeMenu();
                flag=1; 
            }
                break;

            case 3: {
                DetailMenu();
                flag=1; 
            }
                break;
            case 4: {
                printf("\n"); 
            }
                break;
        }
    } while (number!=4 && flag==1);
}

int ShowOrdersSubMenu() {
    int number = 0;
    char buf[16];

    do {

        printf(" (1) Open\n"
               " (2) Range\n"
               " (3) Detail\n"
               " (4) Back\n\n"
               "Enter a number that corresponds to your choice > ");
        if (!fgets(buf, 16, stdin))
            
            number =0;
        else
            
            number = atoi(buf);
        printf("\n");

        if ((number < 1) || (number > 4)) {
            printf("You have entered an invalid choice. Please try again\n\n");
        }
    } while ((number < 1) || (number > 4));

    return number;
}

int OpenMenu ()
{
    int ret;
    
    ret=odbc_connect(&env,&dbc);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
    ret=oOpenMenu(stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    
    ret=disconnect_handle(env, dbc, stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }

    return EXIT_SUCCESS;
}

int RangeMenu()
{
    
    int ret;
    
    ret=odbc_connect(&env,&dbc);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
    ret=rRangeMenu(stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    
    ret=disconnect_handle(env, dbc, stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }

    return EXIT_SUCCESS;
}

int DetailMenu()
{
    int ret;
    SQLHSTMT stmt2 = NULL;


    
    ret = odbc_connect(&env, &dbc);
    if (!SQL_SUCCEEDED(ret)) {
        return EXIT_FAILURE;
    }

    ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt2);
    ret = SQLPrepare(stmt2, (SQLCHAR*) "SELECT sum(total.suma) FROM (SELECT orders.orderdate, orders.status, orderdetails.productcode,  orderdetails.quantityordered, orderdetails.priceeach, (orderdetails.priceeach * orderdetails.quantityordered) as suma, orderdetails.orderlinenumber FROM orders natural join orderdetails natural join products WHERE orders.ordernumber= ? group by orders.orderdate, orders.status, orderdetails.productcode, orderdetails.quantityordered, orderdetails.priceeach, orderdetails.orderlinenumber order by(orderdetails.orderlinenumber)) as total", SQL_NTS);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt2, SQL_HANDLE_ENV);
        return ret;
    }

    ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
    ret=dDetailMenu(stmt,stmt2);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    
    ret=disconnect_handle(env, dbc, stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }

    return EXIT_SUCCESS;
}

/*******************************************************************************CUSTOMERS***********************************************************************/
int ShowCustomersMenu() {
    int number= 0;
    int flag;
    do {
        flag=0; 
        number=ShowCustomersSubMenu();
        switch (number) {

            case 1: {
                FindMenu2();
                flag=1; 
            }
                break;

            case 2: {
                ListProductsMenu();
                flag=1; 
            }
                break;

            case 3: {
                BalanceMenu();
                flag=1; 
            }
                break;
            case 4: {
                printf("\n");
            }
                break;

        }
    } while (number != 4 && flag==1);
    return 0;
}

int ShowCustomersSubMenu() {
    int number = 0;
    char buf[16];

    do {
        
        printf(" (1) Find\n"
               " (2) List Products\n"
               " (3) Balance\n"
               " (4) Back\n\n"
               "Enter a number that corresponds to your choice > ");
        if (!fgets(buf, 16, stdin))
            
            number =0;
        else
            
            number = atoi(buf);
        printf("\n");

        if ((number < 1) || (number > 4)) {
            printf("You have entered an invalid choice. Please try again\n\n");
        }
    } while ((number < 1) || (number > 4));

    return number;
}

int FindMenu2(){
    
    int ret;
    
    ret=odbc_connect(&env,&dbc);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
    ret=fFindMenu2(stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    
    ret=disconnect_handle(env, dbc, stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }

    return EXIT_SUCCESS;
}


int BalanceMenu(){
    
    int ret;
    
    ret=odbc_connect(&env,&dbc);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
    ret=bBalanceMenu(stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    
    ret=disconnect_handle(env, dbc, stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }

    return EXIT_SUCCESS;
}

int ListProductsMenu(){
    
    int ret;
    
    ret=odbc_connect(&env,&dbc);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    ret = SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);
    ret=lListProductsMenu(stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    
    ret=disconnect_handle(env, dbc, stmt);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }

    return EXIT_SUCCESS;
    
}



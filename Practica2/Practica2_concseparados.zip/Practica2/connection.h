#ifndef CON_H
#define CON_H


int pconnect_handle(SQLHENV env, SQLHDBC dbc);




int disconnect_handle(SQLHENV env, SQLHDBC dbc, SQLHSTMT stmt);













#endif
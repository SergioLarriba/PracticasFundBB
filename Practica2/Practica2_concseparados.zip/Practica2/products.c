#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sql.h>
#include <sqlext.h>
#include "odbc.h"
#include "products.h"
#include "connection.h"


#define Buferlen 512
#define Buferlen2 30



int sStockMenu(SQLHSTMT stmt){
    /**/
    int ret;
    char x[Buferlen]="\0";
    char quantityinstock[Buferlen]="\0";

    
    ret= SQLPrepare(stmt, (SQLCHAR*) "SELECT quantityinstock FROM products WHERE productcode = ?", SQL_NTS);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
   
    printf("Enter productcode > ");
    (void) fflush(stdout);
    if(fgets(x, Buferlen, stdin)){
        x[strcspn(x, "\n")]= '\0';
    }
    printf("\n");

    (void) SQLBindParameter(stmt,1,SQL_PARAM_INPUT, SQL_C_CHAR,
                                    SQL_CHAR,0,0,x,0,NULL);
    (void) SQLExecute(stmt);
    (void) SQLBindCol(stmt, 1, SQL_C_CHAR,(SQLCHAR *)quantityinstock,Buferlen/*longitud de dato y*/, NULL);
    
    while (SQL_SUCCEEDED(ret=SQLFetch (stmt))){
        printf("Unidades en stock: %s\n", quantityinstock);
        printf("\n");
    }
    
    (void) SQLCloseCursor(stmt);

        
    return EXIT_SUCCESS;

}
int fFindMenu(SQLHSTMT stmt){
    
    char x[Buferlen]="\0";
    char productcode[Buferlen]="\0";
    char cadena[Buferlen]="%";
    
    int ret;

    
    ret= SQLPrepare(stmt, (SQLCHAR*) "SELECT productcode FROM products WHERE productname like ? ORDER BY productcode", SQL_NTS);
    if (!SQL_SUCCEEDED(ret)) {
        odbc_extract_error("", stmt, SQL_HANDLE_ENV);
        return ret;
    }
    
    printf("Enter productname > ");
    (void) fflush(stdout);
    if(fgets(x, Buferlen, stdin)){
        x[strcspn(x, "\n")]= '\0';
    }
        
    strcat(cadena,x);
    strcat(cadena,"%");

    printf("\n");
    (void) SQLBindParameter(stmt,1,SQL_PARAM_INPUT, SQL_C_CHAR,
                                    SQL_CHAR,0,0,cadena,0,NULL);
    (void) SQLExecute(stmt);
    (void) SQLBindCol(stmt, 1, SQL_C_CHAR,(SQLCHAR *)productcode,Buferlen, NULL);
    
    while (SQL_SUCCEEDED(ret=SQLFetch (stmt))){
        
        printf("%s %s\n", productcode, x);
        printf("\n");
    }

    (void) SQLCloseCursor(stmt);
    
    
    
    return EXIT_SUCCESS;

}
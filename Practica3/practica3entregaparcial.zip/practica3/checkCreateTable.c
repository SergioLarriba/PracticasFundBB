/*
 Created by roberto on 29/8/20.
 */
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
bool createIndex (const char *indexName);
void replaceExtensionByIdx(const char *fileName, char * indexName) {
    int i,lon;
    lon=(int)strlen((char*)fileName);

    for(i=0;i<lon;i++){
        indexName[i]=fileName[i];
        if(fileName[i] == '.') {
            indexName[i+1]='i'; 
            indexName[i+2]='d';
            indexName[i+3]='x'; 
            break;
        }
    }
    
    
    return;
}


bool createTable (const char *tableName){

    FILE *f;
    int num=-1,i,flag=0,lon;
    char tablename2[strlen(tableName)];

    f=fopen((char*)tableName, "rb+");
    if(!f){
        flag=1;
        
        f=fopen(tableName,"wb+");
        fwrite(&num,sizeof(int),1,f);
        fclose(f);
    }

    replaceExtensionByIdx(tableName, tablename2);
    
    if(createIndex(tablename2)==false){
        return false;
    }

    if(flag==0){

        fclose(f);
    }

    return true;
}




bool createIndex (const char *indexName){
    FILE *f;
    int num=-1,i,flag=0;

    f=fopen(indexName, "rb+");
    if(!f){
        flag=1;
        f=fopen(indexName,"wb+");
        fwrite(&num,sizeof(int),1,f);
        fwrite(&num,sizeof(int),1,f);
        fclose(f);
    }

    if(flag==0){
        fclose(f);
    }

    return true ;
}

/*void checkCreateTable(const char * tableName)*/
/**
 *  Tester method for createTable which initializes
 *  a file to store data registers
 * @param tableName: file in which data will be stores
 * @param tableName: program structure that stores
 * a point to the tableName file
*/
int main()
{
    int num = 0;
    struct stat st;
    FILE * dataFileHandler;
    const char *tableName = "myDataBase.dat";
    /* call createTable */
    createTable(tableName);

    /* check file tableName has been created */
    /* and first stored number if -1 */
    dataFileHandler = fopen(tableName, "r");
    fread(&num, sizeof(int), 1, dataFileHandler);
    if (num != -1){
        printf("call to createTable failed\n");
        printf("the first value stored in the file "
               "should be '-1' but is '%d'\n", num);
        exit(1);
    }
    /* check file size */
    stat(tableName, &st);
    if (st.st_size!=sizeof(int))
    {
        printf("call to createTable failed\n");
        printf("the size of file %s should by %ld\n", tableName, sizeof(int));
        exit(1);
    }
    printf("* checkcreateTable: OK\n");
    fclose(dataFileHandler);
    return 0;
}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "utils.h"

int no_deleted_registers = NO_DELETED_REGISTERS;

void replaceExtensionByIdx(const char *fileName, char * indexName) {
    
    lon=(int)strlen((char*)fileName);

    for(i=0;i<lon;i++){
        indexName[i]=fileName[i];
        if(fileName[i] == '.') {
            indexName[i+1]='i'; 
            indexName[i+2]='d';
            indexName[i+3]='x'; 
            break;
        }
    }
    
    
    return;
}


bool createTable (const char *tableName){

    FILE *f;
    int num=-1,i,flag=0,lon;
    char tablename2[strlen(tableName)];

    f=fopen((char*)tableName, "rb+");
    if(!f){
        flag=1;
        
        f=fopen(tableName,"wb+");
        fwrite(&num,sizeof(int),1,f);
        fclose(f);
    }

    
    replaceExtensionByIdx(tableName, tablename2);
    

    

    if(createIndex(tablename2)==false){
        return false;
    }

    if(flag==0){

        fclose(f);
    }

    return true;
}




bool createIndex (const char *indexName){
    FILE *f;
    int num=-1,i,flag=0;

    f=fopen(indexName, "rb+");
    if(!f){
        flag=1;
        f=fopen(indexName,"wb+");
        fwrite(&num,sizeof(int),1,f);
        fwrite(&num,sizeof(int),1,f);
        fclose(f);
    }

    if(flag==0){
        fclose(f);
    }

    return true ;
}



void printnode(size_t _level, size_t level,
               FILE * indexFileHandler, int node_id, char side) {
    
    /*_level es espaciado que dejas al ser llamado por print tree
    level offset
    node_id el identificador q esta entre parentesis
    side l o r*/
    
    return;
}

void printTree(size_t level, const char * indexName)
{
    return;
}
/*
bool findKey(const char * book_id, const char *indexName,
             int * nodeIDOrDataOffset)
 {
     return true;
 }

bool addIndexEntry(char * book_id,  int bookOffset, char const * indexName) {
    return true;
}

bool addTableEntry(Book * book, const char * dataName,
                   const char * indexName) {
    return true;
}*/

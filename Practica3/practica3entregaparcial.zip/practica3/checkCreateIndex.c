/*
// Created by roberto on 29/8/20.
*/

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

bool createIndex (const char *indexName);
bool createTable (const char *tableName){

    FILE *f;
    int num=-1,i,flag=0,lon;
    char tablename2[strlen(tableName)];

    f=fopen((char*)tableName, "rb+");
    if(!f){
        flag=1;
        
        f=fopen(tableName,"wb+");
        fwrite(&num,sizeof(int),1,f);
        fclose(f);
    }

    lon=(int)strlen((char*)tableName);

    for(i=0;i<lon;i++){
        tablename2[i]=tableName[i];
        if(tableName[i] == '.') {
            tablename2[i+1]='i'; 
            tablename2[i+2]='d';
            tablename2[i+3]='x'; 
            break;
        }
    }

    

    

    if(createIndex(tablename2)==false){
        return false;
    }

    if(flag==0){

        fclose(f);
    }

    return true;
}




bool createIndex (const char *indexName){
    FILE *f;
    int num=-1,i,flag=0;

    f=fopen(indexName, "rb+");
    if(!f){
        flag=1;
        f=fopen(indexName,"wb+");
        fwrite(&num,sizeof(int),1,f);
        fwrite(&num,sizeof(int),1,f);
        fclose(f);
    }

    if(flag==0){
        fclose(f);
    }

    return true ;
}

/*void checkCreateIndex(const char * indexName)*/
/**
 *  Tester method for createIndex which initializes
 *  a index over a file to store data registers
 * @param tableName: file in which data will be stores
 * @param indexName: program structure that stores
 * a point to the tableName file
*/
int main()
{
    int num = 0;
    int i = 0;
    struct stat st;
    FILE * indexFileHandler;
    const char *indexName = "myDataBase.idx";
    /* call createTable which calls createIndex*/
    createIndex(indexName);
    /* check file index has been created */
    /* and first TWO stored number are -1 */
    indexFileHandler = fopen(indexName, "r");
    for (i = 0; i < 2; i++) {
        fread(&num, sizeof(int), 1, indexFileHandler);
        if (num != -1) {
            printf("call to checkcreateTablecreateIndex failed\n");
            printf("the %d value stored in the file "
                   "should be '-1' but is '%d'\n", i, num);
            exit(1);
        }
        num = 0;
    }

    /* check file size */
    stat(indexName, &st);
    if (st.st_size!= (2*sizeof(int)))
    {
        printf("call to createTable failed\n");
        printf("the size of file %s should by %ld but it is %ld\n",
               indexName, 2 * sizeof(int), st.st_size);
        exit(1);
    }
    printf("* checkcreateTablecreateIndex: OK\n");
    fclose(indexFileHandler);
    return 0;
}



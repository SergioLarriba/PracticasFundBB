#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "utils.h"

int no_deleted_registers = NO_DELETED_REGISTERS;

void replaceExtensionByIdx(const char *fileName, char * indexName) {
    size_t l;
    l = strlen(fileName);
    strncat(indexName, fileName, l - 3);
    strcat(indexName, "idx");
}


bool createTable(const char * tableName) 
{
    FILE *f=NULL; 
    char *indexName=NULL; 

    /* Abro el fichero */
    f = fopen(tableName, "rb+"); 
    /* Si el fichero no existe, lo creo */
    if (f == NULL) 
    {
        f = fopen(tableName, "wb+"); 
        if (f == NULL) 
            return false; 
        
        /* Escribo -1, que indica que no hay ningun fichero borrado */
        fwrite(&no_deleted_registers, sizeof(int), 1, f); 
    }
    /* Reservo memoria para el nombre del indice */
    indexName = (char*) calloc (strlen(tableName), sizeof(indexName[0]) + 1); 
    if (indexName == NULL) 
        return false;       
    
    /* Cambio el nombre a .idx */
    replaceExtensionByIdx (tableName, indexName); 
    if (createIndex (indexName) == false)
        return false;
    
    free(indexName); 
    fclose (f); 

    return true;
}

bool createIndex(const char *indexName) 
{
    FILE *f=NULL; 

    /* Abro el fichero de indices */
    f = fopen(indexName, "rb+"); 
    /* Si el fichero no existe */
    if (f == NULL)
    {
        f = fopen(indexName, "wb+"); 
        if (f == NULL)
            return false; 

        /* Asigno -1 a los 2 primeros punteros iniciales */
        fwrite(&no_deleted_registers, sizeof(int), 1, f); 
        fwrite(&no_deleted_registers, sizeof(int), 1, f); 
    }

    fclose (f); 
    return true;
}

void printnode(size_t _level, size_t level, FILE * indexFileHandler, int node_id, char side)
{
    Node node;
    size_t pos, i;

    if (node_id == -1 || indexFileHandler == NULL || _level>level)
        return; 

    pos = INDEX_HEADER_SIZE + sizeof (node) * node_id;

    fseek(indexFileHandler, pos, SEEK_SET);
    fread(&node, sizeof(Node), 1, indexFileHandler);
   
    for (i=0; i< _level; i++)
        printf("\t");
    
    printf("%c %.4s (%d): %d\n", side, node.book_id, node_id, node.offset);

    _level++;
    printnode(_level, level, indexFileHandler, node.left, 'l');
    printnode(_level, level, indexFileHandler, node.right, 'r');

    return; 
}

void printTree(size_t level, const char * indexName)
{
    int root;
    FILE *f = NULL;

    if (indexName == NULL)
        return; 

    f = fopen(indexName, "r");
    
    fread(&root, sizeof(int), 1, f);
    if (root == -1)
        return;
    
    printnode(0, level, f, root, ' ');

    fclose (f); 

    return; 
}


bool findKey(const char * book_id, const char *indexName, int * nodeIDOrDataOffset)
{
    FILE *f=NULL; 
    Node node; 
    int root=-1, cmp; 
    size_t pos; 
    bool condition=true; 
    
    if (book_id == NULL || indexName == NULL || nodeIDOrDataOffset == NULL)
        return false; 

    f = fopen (indexName, "rb+"); 
    if (f == NULL)
        return false; 
    /* Leo y guardo la posicion del nodo raiz en root */
    fread(&root, sizeof(int), 1, f); 
    *nodeIDOrDataOffset = root; 

    while (condition == true) /* M*/
    {    
        /* Busco el nodo que ocupa la posicion pos y lo guardo en node */
        pos = INDEX_HEADER_SIZE + sizeof (Node) * (*nodeIDOrDataOffset); 
        fseek (f, pos, SEEK_SET); 
        fread (&node, sizeof(Node), 1, f); 

        /* si los bytes son iguales, he encontrado la llave */
        cmp = memcmp(book_id, node.book_id ,PK_SIZE); 
        if (cmp == 0)
        {
            *nodeIDOrDataOffset = node.offset; 
            fclose (f); 
            return true; 
        }
        else if (cmp > 0) /* Quiere decir que el nodo que buscamos esta por la parte derecha, ya que es mayor que el actual */
        {
            if (node.right == -1) /* Si no existe el nodo derecho al actual, no hemos encontrado la llave */
            {
                fclose (f); 
                return false; 
            }
            else 
                *nodeIDOrDataOffset = node.right; 
        }
        else /* cmp <0 -> quiere decir que el nodo que buscamos esta a la izquierda, ya que es menor que el nodo actual */
        {
            if (node.left == -1) /* Si no existe el nodo izquierdo al actual, no hemos encontrado la llave */
            {
                fclose (f); 
                return false; 
            }
            else 
                *nodeIDOrDataOffset = node.left; 
        }
        condition = true; 
    }

    return true;
}

/* fseek, distinto de 0, va mal */
bool addIndexEntry(char * book_id,  int bookOffset, char const * indexName) {

    FILE *f=NULL; 
    Node node; 
    int ret, deleted_reg=-1, nuevo_nodo=-1, res=-1, nodeIDOrDataOffset; 
    struct stat st; 
    size_t INDEX_REGISTER_SIZE = sizeof(Node); 

    if (book_id == NULL || indexName == NULL)
        return false; 
    
    /* Si existe la clave retorno false */
    res = findKey(book_id, indexName, &nodeIDOrDataOffset);
    if (res)
        return false;
    
    f = fopen(indexName, "rb+"); 
    if (f == NULL)
        return false; 
    
    /* Miro a ver si hay registros borrados */
    ret = fread(&deleted_reg, sizeof(int), 1, f); 
    if (ret == 0) 
        return false; 
    ret = fread(&deleted_reg, sizeof(int), 1, f); 
    if (ret == 0) 
        return false; 
    
    /* Si no hay registros borrados */
    if (deleted_reg == -1)
    {
        ret = fseek(f, 0, SEEK_END);
        if (ret != 0)
            return false; 
        stat(indexName, &st);
        nuevo_nodo = ((st.st_size - INDEX_HEADER_SIZE)/INDEX_REGISTER_SIZE); 
        fprintf (stderr, "Nodo nuevo: %d", nuevo_nodo); 
    }
    /* Si hay registros borrados */
    else 
    {
        /* Leo el nodo borrado */
        ret = fseek(f,deleted_reg * INDEX_REGISTER_SIZE + INDEX_HEADER_SIZE, SEEK_SET); 
        if (ret != 0)
            return false; 
        ret = fread(&node, INDEX_REGISTER_SIZE, 1, f); 
        if (ret == 0)
            return false; 
        nuevo_nodo = deleted_reg; 
        deleted_reg = node.left; 
        /* Actualizo el nodo de la cabecera */
        ret = fseek(f, sizeof(int), SEEK_SET); 
        if (ret != 0)
            return false; 
        ret = fwrite(&deleted_reg, sizeof(int), 1, f); 
        if (ret == 0)
            return false; 
        /* Muevo el puntero */
        ret = fseek(f, nuevo_nodo * INDEX_REGISTER_SIZE + INDEX_HEADER_SIZE, SEEK_SET); 
        if (ret != 0)
            return false; 
    }

    memcpy(node.book_id, book_id, 4); 
    node.offset = bookOffset;
    node.right = -1;
    node.left = -1;
    node.parent = nodeIDOrDataOffset;
    ret = fwrite(&node, INDEX_REGISTER_SIZE, 1, f); 
    /* Guardo y actualizo el padre */
    ret = fseek(f, nodeIDOrDataOffset * INDEX_REGISTER_SIZE + INDEX_HEADER_SIZE, SEEK_SET); 
    if (ret != 0)
        return false; 
    ret = fread(&node, INDEX_REGISTER_SIZE, 1, f); 

    /* Lo inserto */
    res = memcmp(book_id, node.book_id, 4); 
    if (res > 0)
        node.right = nuevo_nodo; 
    else 
        node.left = nuevo_nodo; 
    
    ret = fseek(f, nodeIDOrDataOffset * INDEX_REGISTER_SIZE + INDEX_HEADER_SIZE, SEEK_SET); 
    if (ret != 0)
        return false; 
    ret = fwrite(&node, INDEX_REGISTER_SIZE, 1, f); 
    if (ret == 0)
        return false; 

    ret = fclose (f); 
    
    return true;
}

bool addTableEntry(Book * book, const char * dataName,const char * indexName) {
    int nodeoffset,offset;
    size_t len = strlen(book->title);
    FILE *f=NULL;
	
	f = fopen(dataName, "rb");
	if(!f)
	{
		return false;
	}
	if(fread(&nodeoffset, sizeof(int), 1, f)==0){
        return false;
    }
	if(findKey(book->book_id, indexName, &nodeoffset)==true)
	{
		printf("LA CLAVE EXISTE\n");
		return false;
	}
	
	if(nodeoffset == -1)
	{
		if(fseek(f, SEEK_END,(int)SEEK_SET)==0){
            return false;
        }
		if(fwrite(book->book_id,PK_SIZE, 1, f)==0){
            return false;
        }
		if(fwrite(&len, sizeof(int), 1, f)==0){
            return false;
        }
		if(fwrite(book->title, len, 1, f)==0){
            return false;
        }
		offset = (int)ftell(f);
	}
	if(addIndexEntry(book->book_id, offset, indexName)==false)
	{
		printf("ERROR INTRODUCIENDO EL ÍNDICE\n");
		return false;
	}
	return true;
}



































































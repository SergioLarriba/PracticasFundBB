#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "utils.h"

#define BufferLength 100

int CommandUse(char *dataName); 
int CommandInsert (char *dataName, char *indexName);  
int CommandPrint(char *dataName); 
int ShowMainMenu(); 

int main(){
    int choice=0, flag=0;  
    char *dataName=NULL, *indexName=NULL; 

    dataName = (char*) malloc (BufferLength * sizeof(char)); 
    if (dataName == NULL)
        return -1; 

    do{
        choice=ShowMainMenu();
        switch(choice){
            case 1: {
                flag = 1;  
                if (CommandUse(dataName) != 0) {
                    return -1; 
                }
            }
                break;
            case 2:{
                if (flag == 1) { 
                    if (CommandInsert(dataName, indexName) != 0)
                        return -1; 
                }
                else {
                    fprintf (stdout, "Por favor, váyase primero al comando Use"); 
                }
            }
                break;
            case 3: {
                if (flag == 1) {
                    if (CommandPrint(dataName) != 0) {
                        return -1; 
                    } 
                }
                else
                    fprintf (stdout, "Por favor, váyase primero al comando Use"); 
            }
                break;
            case 4: {
                printf("Has salido");
                printf("\n");
            }
                break;
        }
    }while(choice!=4);

    /* Libero memoria */
    free(dataName); 
    
    return 0;
}

int ShowMainMenu() {
    int number = 0;
    char buf[16];

    do {
        printf("Este programa mostrará un menú de 4 opciones\n");
        printf("Segun el numero que insertes accederas al submenú correspondiente\n\n");

        printf(" (1) Use\n"
               " (2) Insert\n"
               " (3) Print\n"
               " (4) Exit\n\n"
               "Enter a number that corresponds to your choice > ");
        if (!fgets(buf, 16, stdin))
            number =0;
        else
            number = atoi(buf);
        printf("\n");

        if ((number < 1) || (number > 4)) {
            printf("You have entered an invalid choice. Please try again\n\n");
        }
    } while ((number < 1) || (number > 4));

    return number;
}

/* use: El sistema preguntara por el nombre de la tabla a utilizar y llamara a la funcion createTable.*/
int CommandUse (char *dataName)
{   
    /* Leo el valor introducido por el usuario */
    fprintf (stdout, "Introduzca el nombre de la tabla a utilizar (acabado en .dat): ");

    if(fgets(dataName, BufferLength, stdin)){
        dataName[strcspn(dataName, "\n")]= '\0';
    } 

    /* Llamo a la función createTable */
    if (createTable(dataName) == false) {
        fprintf (stdout, "Fallo en la ejecución de createTable\n"); 
        return -1; 
    }
    else {
        fprintf (stdout, "Tabla creada correctamente\n"); 
    }

    return 0; 
}

/* Insert: El sistema preguntar ́a por la clave y el t ́ıtulo a almacenar y llamar ́a
a addTableEntry. Se debe mostrar un mensaje de error si no se ha
seleccionado una tabla antes usando use. Recuerda: (1) addTableEntry
debe llamar a addIndexEntry y (2) tras a ̃nadir un libro al sistema este
debe estar accesible por cualquier otra instancia del mismo programa,
por lo tanto, no se pueden almacenar los datos en memoria si no que
deben almacenarse en disco. */
int CommandInsert (char *dataName, char *indexName)
{
    char key[BufferLength], titulo[BufferLength]; 
    Book *book=NULL; 
    size_t i; 

    if (dataName == NULL)
        return -1; 
    
    /* Reservo momoria para el nuevo libro */
    book = (Book*) malloc (sizeof(Book)); 
    if (book == NULL) 
        return -1; 
    
    /* Reservo memoria para el índice */
    indexName = (char*) malloc(strlen(dataName) * sizeof(char)); 
    if (indexName == NULL)
        return -1; 

    /* Pregunto por la clave a almacenar */
    fprintf (stdout, "Por favor, introduzca la clave: "); 
    if (fgets(key, BufferLength, stdin)) {
        key[strcspn(key, "\n")]='\0'; 
    }

    /* Pregunto por el titulo a almacenar */
    fprintf (stdout, "Por favor, introduzca el título: "); 
    if (fgets(titulo, BufferLength, stdin)) {
        titulo[strcspn(titulo, "\n")]='\0'; 
    } 

    /* Guardo el key en el book_id */ 
    for (i=0; i<PK_SIZE; i++) {
        book->book_id[i] = key[i]; 
    }

    /* Guardo y reservo memoria para insertar los datos del titulo */
    book->title_len = strlen(titulo);
    book->title = (char*) malloc (book->title_len * sizeof(book->title[0])); 
    if (book->title == NULL)
        return -1; 
    for (i=0; i<book->title_len; i++) {
        book->title[i] = titulo[i]; 
    } 

    /* Saco el nombre del índice y llamo a addTableEntry */
    replaceExtensionByIdx (dataName, indexName); 
    if (addTableEntry(book, dataName, indexName) == false)
        return -1; 
    
    /* Libero memoria */
    free(book); 
    free(indexName); 
    
    return 0; 
}

/* Print: Se muestra el  ́arbol binario de b ́usqueda por pantalla. Se debe mostrar
un mensage de error si no se ha seleccionado una tabla antes usando
use. */
int CommandPrint(char *dataName)
{
    char *indexName=NULL; 

    if (dataName == NULL) {
        fprintf (stdout, "Error en los argumentos"); 
        return -1; 
    }
    
    indexName = (char*) calloc (BufferLength, sizeof(char)); 
    if (indexName == NULL){
        fprintf (stdout, "Error al reservar memoria"); 
        return -1; 
    }
    replaceExtensionByIdx (dataName, indexName); 
    
    printTree(250, indexName);

    /* Libero memoria */
    free (indexName); 
    
    return 0; 
}

